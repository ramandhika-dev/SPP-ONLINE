<?php
//variabel koneksi
$konek = mysqli_connect("localhost","root","","ojt");

if(!$konek){
	echo "Koneksi Database Gagal...!!!";
}
?>